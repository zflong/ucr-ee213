To compile:
make parse
make runparse
To run:
./runparse.exe inputfiilename
Example: input filename netlist_t1.sp;
Command:
./runparse.exe netlist_t1.sp